# Imran-Autos-webiste
This project aims to provide a comprehensive online presence for my father's automotive business, empowering it to reach new heights in the digital realm.

Overview: 
Iman Autos is a cutting-edge platform built with a stellar tech stack, ensuring a sleek and robust user experience.
Our technology stack includes:

Frontend:HTML, CSS, JavaScript, Bootstrap 
Backend: Django, Jinja Database: MongoDB 
API Integration: Fetch API Features User Panel Services and Products: Explore an extensive array of services and products, including the powerful 'Imran Excavator'. 
User-Friendly Interface: Easy navigation and an intuitive layout ensure a seamless experience for our clients. 
Contact Page: Effortlessly connect with us through our dedicated contact page. 
Admin Panel Content Management: Admins can easily manage website content, from adding and updating products to deleting outdated listings. 
Seamless Control: Our admin panel offers a user-friendly interface for efficient content management.
